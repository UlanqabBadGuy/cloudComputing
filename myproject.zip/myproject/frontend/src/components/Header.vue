<template>
  <div id="Header">
    <div class="top-left-edition">
      <span>
        <i class="el-icon-time" style="font-size: 23px"></i> 2024.05 finished
      </span>
    </div>
    <div id="word">
      <h1>{{ msg }}</h1>
    </div>
  </div>
</template>
<script>
export default {
  name: "Header",
  data() {
    return {
      msg: "Bronchoalveolar lavage fluid cell classification detection model based on YOLOv5s",
      activeIndex: "1",
    };
  },
  methods: {},
};
</script>
<style scoped>
#Header {
  padding: 30px 110px 0 150px;
  width: 90%;
  margin: 10px auto;
}

#word {
  /*margin-left: 45%;*/
  margin-top: -10px;
  margin-bottom: 30px;
  /*height: 60px;*/
  /*line-height: 3.2em;*/
  letter-spacing: 4px;
}

h1 {
  font-size: 18px !important;
  /*text-align: center;*/
  color: #21b3b9;
  letter-spacing: 0px;
}

.el-menu-demo {
  width: 80%;
  margin: 0px auto;
  padding: 0px auto;
}

.top-left-edition span i {
  float: left;
  margin-right: 10px;
}

i,
input,
label {
  vertical-align: middle;
}

i {
  border: 0;
  display: block;
  cursor: pointer;
}

.top-left-edition span {
  float: left;
  font-size: 16px;
  color: #999999;
  line-height: 24px;
  margin-right: 40px;
}
</style>


