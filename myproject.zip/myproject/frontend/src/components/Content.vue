<template>
  <div id="Content">
    <el-dialog
        title="AI forecasting"
        :visible.sync="dialogTableVisible"
        :show-close="false"
        :close-on-press-escape="false"
        :append-to-body="true"
        :close-on-click-modal="false"
        :center="true"
    >
      <el-progress :percentage="percentage"></el-progress>
      <span slot="footer" class="dialog-footer">Please wait for a while</span>
    </el-dialog>

    <div id="CT">
      <div id="CT_image">
        <el-card
            id="CT_image_1"
            class="box-card"
            style="
            border-radius: 8px;
            width: 800px;
            height: 360px;
            margin-bottom: -30px;
          "
        >
          <div class="demo-image__preview1">
            <div
                v-loading="loading"
                element-loading-text="uploading 图片"
                element-loading-spinner="el-icon-loading"
            >
              <el-image
                  :src="url_1"
                  class="image_1"
                  :preview-src-list="srcList"
                  style="border-radius: 3px 3px 0 0"
              >
                <div slot="error">
                  <div slot="placeholder" class="error">
                    <el-button
                        v-show="showbutton"
                        type="primary"
                        icon="el-icon-upload"
                        class="download_bt"
                        v-on:click="true_upload"
                    >
                      upload RGB image
                      <input
                          ref="upload"
                          style="display: none"
                          name="file"
                          type="file"
                          @change="update"
                      />
                    </el-button>

                    <el-button
                        v-show="showbutton"
                        type="primary"
                        icon="el-icon-upload"
                        class="download_bt2"
                        v-on:click="true_upload2"
                    >
                      upload HSV image
                      <input
                          ref="upload2"
                          style="display: none"
                          name="file"
                          type="file"
                          @change="update_hsv"
                      />
                    </el-button>


                  </div>
                </div>
              </el-image>
            </div>
            <div class="img_info_1" style="border-radius: 0 0 5px 5px">
              <span style="color: white; letter-spacing: 6px">Raw Image</span>
            </div>
          </div>
          <div class="demo-image__preview2">
            <div
                v-loading="loading"
                element-loading-text="Processing ~~~~"
                element-loading-spinner="el-icon-loading"
            >
              <el-image
                  :src="url_2"
                  class="image_1"
                  :preview-src-list="srcList1"
                  style="border-radius: 3px 3px 0 0"
              >
                <div slot="error">
                  <div slot="placeholder" class="error">{{ wait_return }}</div>
                </div>
              </el-image>
            </div>
            <div class="img_info_1" style="border-radius: 0 0 5px 5px">
              <span style="color: white; letter-spacing: 4px">Result</span>
            </div>
          </div>
        </el-card>
      </div>
      <div id="info_patient">
        <!-- 卡片放置表格 -->
        <el-card style="border-radius: 8px">
          <div slot="header" class="clearfix">
            <span>OBJECT DETECTION</span>
            <el-button
                style="margin-left: 35px"
                v-show="!showbutton"
                type="primary"
                icon="el-icon-upload"
                class="download_bt"
                v-on:click="true_upload3"
            >
              Select another RGB Image
              <input
                  ref="upload3"
                  style="display: none"
                  name="file"
                  type="file"
                  @change="update"
              />
            </el-button>
            <el-button
                style="margin-left: 35px"
                v-show="!showbutton"
                type="primary"
                icon="el-icon-upload"
                class="download_bt"
                v-on:click="true_upload4"
            >
              Select another HSV Image
              <input
                  ref="upload4"
                  style="display: none"
                  name="file"
                  type="file"
                  @change="update_hsv"
              />
            </el-button>
          </div>
          <el-tabs v-model="activeName">
            <el-tab-pane label="Detected Objects (The image comparison may be loaded slowly due to network :<)"
                         name="first">
              <!-- 表格存放特征值 -->
              <el-table
                  :data="feature_list"
                  height="390"
                  border
                  style="width: 750px; text-align: center"
                  v-loading="loading"
                  element-loading-text="Image is processing in the backend"
                  element-loading-spinner="el-icon-loading"
                  lazy
              >
                <el-table-column label="TYPE" width="250px">
                  <template slot-scope="scope">
                    <span>{{ scope.row[2] }}</span>
                  </template>
                </el-table-column>
                <el-table-column label="OBJECT SIZE" width="250px">
                  <template slot-scope="scope">
                    <span>{{ scope.row[0] }}</span>
                  </template>
                </el-table-column>
                <el-table-column label="CONFIDENCE" width="250px">
                  <template slot-scope="scope">
                    <span>{{ scope.row[1] }}</span>
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "Content",
  data() {
    return {
      server_url: "http://localhost:5003",
      activeName: "first",
      active: 0,
      centerDialogVisible: true,
      url_1: "",
      url_2: "",
      textarea: "",
      srcList: [],
      srcList1: [],
      feature_list: [],
      feature_list_1: [],
      feat_list: [],
      url: "",
      visible: false,
      wait_return: "wait upload",
      wait_upload: "wait upload",
      loading: false,
      table: false,
      isNav: false,
      showbutton: true,
      percentage: 0,
      fullscreenLoading: false,
      opacitys: {
        opacity: 0,
      },
      dialogTableVisible: false,
    };
  },
  created: function () {
    document.title = "YOLOv5 Object Detection Deployment";
  },
  methods: {
    true_upload() {
      this.$refs.upload.click();
    },
    true_upload2() {
      this.$refs.upload2.click();
    },
    true_upload3() {
      this.$refs.upload3.click();
    },
    true_upload4() {
      this.$refs.upload4.click();
    },
    next() {
      this.active++;
    },
    // 获得目标文件
    getObjectURL(file) {
      var url = null;
      if (window.createObjcectURL != undefined) {
        url = window.createOjcectURL(file);
      } else if (window.URL != undefined) {
        url = window.URL.createObjectURL(file);
      } else if (window.webkitURL != undefined) {
        url = window.webkitURL.createObjectURL(file);
      }
      return url;
    },
    // 上传文件
    update(e) {
      this.percentage = 0;
      this.dialogTableVisible = true;
      this.url_1 = "";
      this.url_2 = "";
      this.srcList = [];
      this.srcList1 = [];
      this.wait_return = "";
      this.wait_upload = "";
      this.feature_list = [];
      this.feat_list = [];
      this.fullscreenLoading = true;
      this.loading = true;
      this.showbutton = false;
      let file = e.target.files[0];
      this.url_1 = this.$options.methods.getObjectURL(file);
      let param = new FormData(); //创建form对象
      param.append("file", file, file.name); //通过append向form对象添加数据
      var timer = setInterval(() => {
        this.myFunc();
      }, 30);
      window.console.log("raw");
      let config = {
        headers: {"Content-Type": "multipart/form-data"},
      }; //添加请求头
      axios
          .post(this.server_url + "/upload", param, config)
          .then((response) => {
            this.percentage = 100;
            clearInterval(timer);
            this.url_1 = response.data.image_url;
            this.srcList.push(this.url_1);
            this.url_2 = response.data.draw_url;
            this.srcList1.push(this.url_2);
            this.fullscreenLoading = false;
            this.loading = false;

            this.feat_list = Object.keys(response.data.image_info);

            for (var i = 0; i < this.feat_list.length; i++) {
              response.data.image_info[this.feat_list[i]][2] = this.feat_list[i];
              this.feature_list.push(response.data.image_info[this.feat_list[i]]);
            }

            this.feature_list.push(response.data.image_info);
            this.feature_list_1 = this.feature_list[0];
            this.dialogTableVisible = false;
            this.percentage = 0;

            let result_count = {"Eosinophil": 0, "Lymphocyte": 0, "Macrophage": 0, "Neutrophil": 0};

            for (var object in response.data.image_info) {
              if (object.toString().includes("Eosinophil")) {
                result_count.Eosinophil = result_count.Eosinophil + 1;
              } else if (object.toString().includes("Lymphocyte")) {
                result_count.Lymphocyte = result_count.Lymphocyte + 1;
              } else if (object.toString().includes("Macrophage")) {
                result_count.Macrophage = result_count.Macrophage + 1;
              } else if (object.toString().includes("Neutrophil")) {
                result_count.Neutrophil = result_count.Neutrophil + 1;
              }
            }

            window.console.log(result_count);
            this.notice1(result_count);
          });
    },
    // 上传文件
    update_hsv(e) {
      this.percentage = 0;
      this.dialogTableVisible = true;
      this.url_1 = "";
      this.url_2 = "";
      this.srcList = [];
      this.srcList1 = [];
      this.wait_return = "";
      this.wait_upload = "";
      this.feature_list = [];
      this.feat_list = [];
      this.fullscreenLoading = true;
      this.loading = true;
      this.showbutton = false;
      let file = e.target.files[0];
      this.url_1 = this.$options.methods.getObjectURL(file);
      let param = new FormData(); //创建form对象
      param.append("file", file, file.name); //通过append向form对象添加数据
      window.console.log("hsv");
      var timer = setInterval(() => {
        this.myFunc();
      }, 30);
      let config = {
        headers: {"Content-Type": "multipart/form-data"},
      }; //添加请求头
      axios
          .post(this.server_url + "/upload_hsv", param, config)
          .then((response) => {
            this.percentage = 100;
            clearInterval(timer);
            this.url_1 = response.data.image_url;
            this.srcList.push(this.url_1);
            this.url_2 = response.data.draw_url;
            this.srcList1.push(this.url_2);
            this.fullscreenLoading = false;
            this.loading = false;

            this.feat_list = Object.keys(response.data.image_info);

            for (var i = 0; i < this.feat_list.length; i++) {
              response.data.image_info[this.feat_list[i]][2] = this.feat_list[i];
              this.feature_list.push(response.data.image_info[this.feat_list[i]]);
            }

            this.feature_list.push(response.data.image_info);
            this.feature_list_1 = this.feature_list[0];
            this.dialogTableVisible = false;
            this.percentage = 0;

            let result_count = {"Eosinophil": 0, "Lymphocyte": 0, "Macrophage": 0, "Neutrophil": 0};

            for (var object in response.data.image_info) {
              if (object.toString().includes("Eosinophil")) {
                result_count.Eosinophil = result_count.Eosinophil + 1;
              } else if (object.toString().includes("Lymphocyte")) {
                result_count.Lymphocyte = result_count.Lymphocyte + 1;
              } else if (object.toString().includes("Macrophage")) {
                result_count.Macrophage = result_count.Macrophage + 1;
              } else if (object.toString().includes("Neutrophil")) {
                result_count.Neutrophil = result_count.Neutrophil + 1;
              }
            }
            window.console.log(result_count);
            this.notice1(result_count);
          });
    },
    myFunc() {
      if (this.percentage + 33 < 99) {
        this.percentage = this.percentage + 33;
      } else {
        this.percentage = 99;
      }
    },
    drawChart() {
    },
    notice1(result_count) {
      let data = [
        "Click on image to see larger image\n",
        "<<<<< Objects Counting >>>>>",
        "\"Eosinophil:\"" + result_count.Eosinophil,
        "\"Lymphocyte:\"" + result_count.Lymphocyte,
        "\"Macrophage:\"" + result_count.Macrophage,
        "\"Neutrophil:\"" + result_count.Neutrophil,
      ];
      let newDatas = [];
      const h = this.$createElement;
      for (let i in data) {
        newDatas.push(h('p', null, data[i]));
      }
      this.$notify({
        title: "Forecast Finish",
        message: h('div', {style: 'text-align:center'}, newDatas),
        duration: 0,
        type: "success",
      });
    },
  },
  mounted() {
    this.drawChart();
  },
};
</script>

<style>
.el-button {
  padding: 12px 20px !important;
}

#hello p {
  font-size: 15px !important;
  /*line-height: 25px;*/
}

.n1 .el-step__description {
  padding-right: 20%;
  font-size: 14px;
  line-height: 20px;
  /* font-weight: 400; */
}
</style>

<style scoped>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.dialog_info {
  margin: 20px auto;
}

.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}

.clearfix:after {
  clear: both;
}

.box-card {
  width: 680px;
  height: 200px;
  border-radius: 8px;
  margin-top: -20px;
}

.divider {
  width: 50%;
}

#CT {
  display: flex;
  height: 100%;
  width: 100%;
  flex-wrap: wrap;
  justify-content: center;
  margin: 0 auto;
  margin-right: 0px;
  max-width: 1800px;
}

#CT_image_1 {
  width: 90%;
  height: 40%;
  margin: 0px auto;
  padding: 0px auto;
  margin-right: 180px;
  margin-bottom: 0px;
  border-radius: 4px;
}

#CT_image {
  margin-bottom: 60px;
  margin-left: 30px;
  margin-top: 5px;
}

.image_1 {
  width: 275px;
  height: 260px;
  background: #ffffff;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.img_info_1 {
  height: 30px;
  width: 275px;
  text-align: center;
  background-color: #21b3b9;
  line-height: 30px;
}

.demo-image__preview1 {
  width: 250px;
  height: 290px;
  margin: 20px 60px;
  float: left;
}

.demo-image__preview2 {
  width: 250px;
  height: 290px;

  margin: 20px 460px;
  /* background-color: green; */
}

.error {
  margin: 100px auto;
  margin-top: 25%;
  /*width: 58%;*/
  padding: 10px;
  text-align: center;
}

.el-card__header .el-button {
  margin: 0 20px !important;
}

.block-sidebar {
  position: fixed;
  display: none;
  left: 50%;
  margin-left: 600px;
  top: 350px;
  width: 60px;
  z-index: 99;
}

.block-sidebar .block-sidebar-item {
  font-size: 50px;
  color: lightblue;
  text-align: center;
  line-height: 50px;
  margin-bottom: 20px;
  cursor: pointer;
  display: block;
}

div {
  display: block;
}

.block-sidebar .block-sidebar-item:hover {
  color: #187aab;
}

.download_bt {
  /*margin-left: -15px !important;*/
  margin-top: 15px;
  padding: 10px 16px !important;
}

.el-button + .el-button {
  margin-left: 0 !important;
}

.download_bt2 {
  /*margin-left: -15px !important;*/
  margin-top: 15px;
  padding: 10px 16px !important;
}

#upfile {
  width: 104px;
  height: 45px;
  background-color: #187aab;
  color: #fff;
  text-align: center;
  line-height: 45px;
  border-radius: 3px;
  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.2);
  color: #fff;
  font-family: "Source Sans Pro", Verdana, sans-serif;
  font-size: 0.875rem;
}

.file {
  width: 200px;
  height: 130px;
  position: absolute;
  left: -20px;
  top: 0;
  z-index: 1;
  -moz-opacity: 0;
  -ms-opacity: 0;
  -webkit-opacity: 0;
  opacity: 0; /*css属性&mdash;&mdash;opcity不透明度，取值0-1*/
  filter: alpha(opacity=0);
  cursor: pointer;
}

#upload {
  position: relative;
  margin: 0px 0px;
}

#Content {
  width: 85%;
  height: 100%;
  /*background-color: #ffffff;*/
  margin: 15px auto;
  display: flex;
  min-width: 1200px;
}

.divider {
  background-color: #eaeaea !important;
  height: 2px !important;
  width: 100%;
  margin-bottom: 50px;
}

.divider_1 {
  background-color: #ffffff;
  height: 2px !important;
  width: 100%;
  margin-bottom: 20px;
  margin: 20px auto;
}

.steps {
  font-family: "lucida grande", "lucida sans unicode", lucida, helvetica,
  "Hiragino Sans GB", "Microsoft YaHei", "WenQuanYi Micro Hei", sans-serif;
  color: #21b3b9;
  text-align: center;
  margin: 15px auto;
  font-size: 20px;
  font-weight: bold;
  text-align: center;
}

.step_1 {
  /*color: #303133 !important;*/
  margin: 20px 26px;
}

#info_patient {
  margin-top: 10px;
  margin-right: 160px;
}
</style>


